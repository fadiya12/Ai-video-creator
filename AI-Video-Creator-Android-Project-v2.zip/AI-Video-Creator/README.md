# AI Video Creator — Android

This Android wrapper loads the published StoryReel web app inside a native Android WebView.

App URL: https://project-ai-video-creator-107.magicpatterns.app/

## Test build
Use the included GitHub Actions workflow (`Build AI Video Creator APK`) to create a debug APK. The APK is uploaded as a workflow artifact for installation on an Android test device.

## Release
For Google Play, create a signed Android App Bundle (AAB) and complete Play Console testing/release requirements.
